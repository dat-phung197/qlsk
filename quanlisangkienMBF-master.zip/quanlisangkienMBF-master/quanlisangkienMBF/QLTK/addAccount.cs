﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlisangkienMBF
{
    public partial class addAccount : Form
    {
        ConnectDB con = new ConnectDB();
        public addAccount()
        {
            InitializeComponent();
        }
        void loadcombobox()
        {
            ConnectDB con = new ConnectDB();
            con.openConnect();
            string sql = "select * from quyen ";
            var cmd = new SqlCommand(sql, con.con);
            var dr = cmd.ExecuteReader();
            var dt = new DataTable();
            dt.Load(dr);
            dr.Dispose();
            comboBox1.DisplayMember = "tenquyen";
            comboBox1.ValueMember = "maquyen";
            comboBox1.DataSource = dt;
            con.closeConnect();
        }
        private void addAccount_Load(object sender, EventArgs e)
        {
            loadTaikhoan();
            ////
            ConnectDB con = new ConnectDB();
            con.openConnect();
            string sql1 = "select * from nhanvien";
            var cmd1 = new SqlCommand(sql1, con.con);
            var dr1 = cmd1.ExecuteReader();
            var dt1 = new DataTable();
            dt1.Load(dr1);
            dr1.Dispose();
            comboBox2.DisplayMember = "tennhanvien";
            comboBox2.ValueMember = "manhanvien";
            comboBox2.DataSource = dt1;
            con.closeConnect();
        }
        public void loadTaikhoan()
        {
            loadcombobox();
            CRUD crud = new CRUD();
            string sql = "select * from taikhoan";
            dataGridView1.DataSource = crud.getDataTable(sql);
        }
        private void btn_thoat_Click(object sender, EventArgs e)
        {
            DialogResult h = MessageBox.Show
                ("Bạn có chắc muốn thoát không?", "Error", MessageBoxButtons.OKCancel);
            if (h == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void btn_dk_Click(object sender, EventArgs e)
        {
            
            string email = txt_email.Text;
            string mk = txt_mk.Text;
            con.openConnect();
            string mnv = comboBox2.SelectedValue.ToString();
            string maquyen = comboBox1.SelectedValue.ToString();
            SqlDataReader dulieu;
            string sql = "select * from TaiKhoan Where manhanvien = '" + mnv + "' ";
            SqlCommand cmd = new SqlCommand(sql, con.con);
            dulieu = cmd.ExecuteReader() ;
            if (email.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập email");
                txt_email.Focus();
            }
            else if (mk.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập mật khẩu");
                txt_mk.Focus();
            }
            else if (maquyen.Trim() == "")
            {
                MessageBox.Show("Chưa chọn quyền hạn cho tài khoản này");
                comboBox1.Focus();
            }
            else if (mnv.Trim() == "")
            {
                MessageBox.Show("Chưa có đối đượng để tạo tài khoản");
                comboBox2.Focus();
            }
            else if (dulieu.Read() == true)
            {
                MessageBox.Show("Tài khoản của người này đã tồn tại");
            }
            else
            {
                try
                {
                    con.closeConnect();
                    con.openConnect();
                    string sqlQuery = "INSERT INTO taikhoan VALUES (@tentaikhoan,@matkhau,@manhanvien,@maquyen)";
                    SqlCommand cmd1 = new SqlCommand(sqlQuery, con.con);
                    cmd1.Parameters.AddWithValue("tentaikhoan", txt_email.Text);
                    cmd1.Parameters.AddWithValue("matkhau", txt_mk.Text);
                    cmd1.Parameters.AddWithValue("manhanvien", mnv.ToString());
                    cmd1.Parameters.AddWithValue("maquyen",maquyen.ToString());
                    cmd1.ExecuteNonQuery();
                    con.closeConnect();
                    MessageBox.Show("Đăng kí thành công","Thông báo");
                    loadTaikhoan();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi không xác định", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            try
            {
                string email = txt_email.Text;
                string mk = txt_mk.Text;
                string mnv = comboBox2.SelectedValue.ToString();
                string maquyen = comboBox1.SelectedValue.ToString();
                con.closeConnect();
                con.openConnect();
                string sqlDelete = "DELETE FROM taikhoan WHERE manhanvien = @manhanvien";
                SqlCommand cmd1 = new SqlCommand(sqlDelete, con.con);
                cmd1.Parameters.AddWithValue("tentaikhoan", txt_email.Text);
                cmd1.Parameters.AddWithValue("matkhau", txt_mk.Text);
                cmd1.Parameters.AddWithValue("manhanvien", mnv.ToString());
                cmd1.Parameters.AddWithValue("maquyen", maquyen.ToString());
                cmd1.ExecuteNonQuery();
                con.closeConnect();
                loadTaikhoan();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Tên tài khoản đã tồn tại" + ex, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {

                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                txt_email.Text = row.Cells[0].Value.ToString();
                txt_mk.Text = row.Cells[1].Value.ToString();
            }
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            try
            {
                string email = txt_email.Text;
                string mk = txt_mk.Text;
                string mnv = comboBox2.SelectedValue.ToString();
                string maquyen = comboBox1.SelectedValue.ToString();
                con.closeConnect();
                con.openConnect();
                string sqlEdit = "UPDATE taikhoan SET matkhau = @matkhau,manhanvien = @manhanvien,maquyen = @maquyen WHERE tentaikhoan = @tentaikhoan";
                SqlCommand cmd1 = new SqlCommand(sqlEdit, con.con);
                cmd1.Parameters.AddWithValue("tentaikhoan", txt_email.Text);
                cmd1.Parameters.AddWithValue("matkhau", txt_mk.Text);
                cmd1.Parameters.AddWithValue("manhanvien", mnv.ToString());
                cmd1.Parameters.AddWithValue("maquyen", maquyen.ToString());
                cmd1.ExecuteNonQuery();
                con.closeConnect();
                loadTaikhoan();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Tên tài khoản đã tồn tại" + ex, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

    }
}
