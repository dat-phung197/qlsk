﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlisangkienMBF
{
    public partial class Myidea : Form
    {
        int msk;
        ConnectDB con = new ConnectDB();
        public Myidea(int i)
        {
            InitializeComponent();
            msk = i;
        }
        private void Myidea_Load(object sender, EventArgs e)
        {
            con.openConnect();
            SqlDataReader dulieu2;
            string sqlcount = "select * from view_myidea where masangkien = '" + msk + "'";
            SqlCommand cmd3 = new SqlCommand(sqlcount, con.con);
            dulieu2 = cmd3.ExecuteReader();
            if (dulieu2.Read() == true)
            {
                txt_msk.Text = dulieu2.GetInt32(0).ToString();
                txt_tensk.Text = dulieu2.GetString(1);
                txt_dsk.Text = dulieu2.GetInt32(2).ToString();
                txt_muctieu.Text = dulieu2.GetString(3);
                txt_noidung.Text = dulieu2.GetString(4);
                txt_loiich.Text = dulieu2.GetString(5);
                txt_doituong.Text = dulieu2.GetString(6);
                txt_tt.Text = dulieu2.GetString(7).ToString();
                txt_dk.Text = dulieu2.GetString(8);
                txt_cd.Text = dulieu2.GetString(9);
                con.closeConnect();
            }
            con.openConnect();
            string sql = "select * from chitietchamdiem where masangkien = '" + msk + "'";
            SqlCommand cmd = new SqlCommand(sql, con.con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            float total = 0;
            for(int i = 0; i < dt.Rows.Count; i++)
            {
                if(i == 0)
                {
                    d1.Text = dt.Rows[0].ItemArray[2].ToString();
                    d2.Text = dt.Rows[0].ItemArray[3].ToString();
                    d3.Text = dt.Rows[0].ItemArray[4].ToString();
                    d4.Text = dt.Rows[0].ItemArray[5].ToString();
                    int diem1 = int.Parse(d1.Text);
                    int diem2 = int.Parse(d2.Text);
                    int diem3 = int.Parse(d3.Text);
                    int diem4 = int.Parse(d4.Text);
                    total = total +diem1 + diem2 + diem3 + diem4;

                }
                if(i == 1)
                {
                    d11.Text = dt.Rows[1].ItemArray[2].ToString();
                    d12.Text = dt.Rows[1].ItemArray[3].ToString();
                    d13.Text = dt.Rows[1].ItemArray[4].ToString();
                    d14.Text = dt.Rows[1].ItemArray[5].ToString();
                    int diem11 = int.Parse(d11.Text);
                    int diem12 = int.Parse(d12.Text);
                    int diem13 = int.Parse(d13.Text);
                    int diem14 = int.Parse(d14.Text);
                    total = total + diem11 + diem12 + diem13 + diem14;
                }
                if (i == 2)
                {
                    d21.Text = dt.Rows[2].ItemArray[2].ToString();
                    d22.Text = dt.Rows[2].ItemArray[3].ToString();
                    d23.Text = dt.Rows[2].ItemArray[4].ToString();
                    d24.Text = dt.Rows[2].ItemArray[5].ToString();
                    int diem21 = int.Parse(d21.Text);
                    int diem22 = int.Parse(d22.Text);
                    int diem23 = int.Parse(d23.Text);
                    int diem24 = int.Parse(d24.Text);
                    total = total + diem21 + diem22 + diem23 + diem24;
                }
            }
            con.closeConnect();
            if(txt_tt.Text == "Hoàn thành")
            {
                total = total/12;
                txt_total.Text = total.ToString();
                if(total > 9 && total <= 10)
                {
                    txt_xeploai.Text = "Xuất sắc";
                }
                else if(total <= 9 && total > 8)
                {
                    txt_xeploai.Text = "Giỏi";
                }
                else if (total <= 8 && total > 6)
                {
                    txt_xeploai.Text = "Khá";
                }
                else if (total <= 6 && total > 5)
                {
                    txt_xeploai.Text = "Trung bình";
                }
                else
                {
                    txt_xeploai.Text = "Yếu";
                }
            }
        }


    }
}
