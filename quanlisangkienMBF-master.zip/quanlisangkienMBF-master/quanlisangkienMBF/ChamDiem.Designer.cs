﻿namespace quanlisangkienMBF
{
    partial class ChamDiem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_re = new System.Windows.Forms.Button();
            this.btn_ht = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.txt_msk = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_chitiet = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_nx = new System.Windows.Forms.TextBox();
            this.num_tb = new System.Windows.Forms.NumericUpDown();
            this.lb_tb = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.num_nd = new System.Windows.Forms.NumericUpDown();
            this.num_ud = new System.Windows.Forms.NumericUpDown();
            this.num_md = new System.Windows.Forms.NumericUpDown();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_tb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_nd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_ud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_md)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 278);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(878, 335);
            this.panel1.TabIndex = 14;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tabControl1.Location = new System.Drawing.Point(0, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(878, 331);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(870, 305);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sáng kiến chưa chấm";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(864, 299);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(870, 305);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Sáng kiến đã chấm";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(864, 299);
            this.dataGridView2.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_re);
            this.panel2.Controls.Add(this.btn_ht);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.txt_msk);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.btn_chitiet);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.txt_nx);
            this.panel2.Controls.Add(this.num_tb);
            this.panel2.Controls.Add(this.lb_tb);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.num_nd);
            this.panel2.Controls.Add(this.num_ud);
            this.panel2.Controls.Add(this.num_md);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(878, 276);
            this.panel2.TabIndex = 15;
            // 
            // btn_re
            // 
            this.btn_re.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_re.Location = new System.Drawing.Point(53, 203);
            this.btn_re.Name = "btn_re";
            this.btn_re.Size = new System.Drawing.Size(100, 37);
            this.btn_re.TabIndex = 34;
            this.btn_re.Text = "Reload";
            this.btn_re.UseVisualStyleBackColor = true;
            this.btn_re.Click += new System.EventHandler(this.btn_re_Click);
            // 
            // btn_ht
            // 
            this.btn_ht.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ht.Location = new System.Drawing.Point(324, 203);
            this.btn_ht.Name = "btn_ht";
            this.btn_ht.Size = new System.Drawing.Size(100, 37);
            this.btn_ht.TabIndex = 33;
            this.btn_ht.Text = "Hoàn thành";
            this.btn_ht.UseVisualStyleBackColor = true;
            this.btn_ht.Click += new System.EventHandler(this.btn_ht_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(349, 141);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 35);
            this.button2.TabIndex = 32;
            this.button2.Text = "Tìm kiếm";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txt_msk
            // 
            this.txt_msk.Location = new System.Drawing.Point(205, 146);
            this.txt_msk.Name = "txt_msk";
            this.txt_msk.Size = new System.Drawing.Size(138, 20);
            this.txt_msk.TabIndex = 31;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(80, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 19);
            this.label4.TabIndex = 30;
            this.label4.Text = "Mã sáng kiến";
            // 
            // btn_chitiet
            // 
            this.btn_chitiet.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_chitiet.Location = new System.Drawing.Point(188, 203);
            this.btn_chitiet.Name = "btn_chitiet";
            this.btn_chitiet.Size = new System.Drawing.Size(100, 37);
            this.btn_chitiet.TabIndex = 29;
            this.btn_chitiet.Text = "Xem chi tiết";
            this.btn_chitiet.UseVisualStyleBackColor = true;
            this.btn_chitiet.Click += new System.EventHandler(this.btn_chitiet_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(468, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 19);
            this.label5.TabIndex = 28;
            this.label5.Text = "Nhận xét";
            // 
            // txt_nx
            // 
            this.txt_nx.Location = new System.Drawing.Point(471, 149);
            this.txt_nx.Multiline = true;
            this.txt_nx.Name = "txt_nx";
            this.txt_nx.Size = new System.Drawing.Size(309, 91);
            this.txt_nx.TabIndex = 27;
            // 
            // num_tb
            // 
            this.num_tb.Location = new System.Drawing.Point(660, 73);
            this.num_tb.Name = "num_tb";
            this.num_tb.Size = new System.Drawing.Size(120, 20);
            this.num_tb.TabIndex = 26;
            // 
            // lb_tb
            // 
            this.lb_tb.AutoSize = true;
            this.lb_tb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tb.Location = new System.Drawing.Point(657, 38);
            this.lb_tb.Name = "lb_tb";
            this.lb_tb.Size = new System.Drawing.Size(108, 19);
            this.lb_tb.TabIndex = 25;
            this.lb_tb.Text = "Điểm trình bày";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(468, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 19);
            this.label3.TabIndex = 24;
            this.label3.Text = "Điểm ứng dụng";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(271, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 19);
            this.label2.TabIndex = 23;
            this.label2.Text = "Điểm nội dung";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(84, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 19);
            this.label1.TabIndex = 22;
            this.label1.Text = "Điểm mục đích";
            // 
            // num_nd
            // 
            this.num_nd.Location = new System.Drawing.Point(274, 73);
            this.num_nd.Name = "num_nd";
            this.num_nd.Size = new System.Drawing.Size(120, 20);
            this.num_nd.TabIndex = 21;
            // 
            // num_ud
            // 
            this.num_ud.Location = new System.Drawing.Point(471, 74);
            this.num_ud.Name = "num_ud";
            this.num_ud.Size = new System.Drawing.Size(120, 20);
            this.num_ud.TabIndex = 20;
            // 
            // num_md
            // 
            this.num_md.Location = new System.Drawing.Point(84, 73);
            this.num_md.Name = "num_md";
            this.num_md.Size = new System.Drawing.Size(120, 20);
            this.num_md.TabIndex = 19;
            // 
            // ChamDiem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 613);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "ChamDiem";
            this.Text = "Điểm ứng dụng";
            this.Load += new System.EventHandler(this.ChamDiem_Load);
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_tb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_nd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_ud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_md)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txt_msk;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_chitiet;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_nx;
        private System.Windows.Forms.NumericUpDown num_tb;
        private System.Windows.Forms.Label lb_tb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown num_nd;
        private System.Windows.Forms.NumericUpDown num_ud;
        private System.Windows.Forms.NumericUpDown num_md;
        private System.Windows.Forms.Button btn_ht;
        private System.Windows.Forms.Button btn_re;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView2;
    }
}