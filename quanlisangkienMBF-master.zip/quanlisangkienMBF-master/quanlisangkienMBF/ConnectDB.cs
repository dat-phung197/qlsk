﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace quanlisangkienMBF
{
    public class ConnectDB
    {
        public SqlConnection con = new SqlConnection();
        string connectString = @"Data Source=DESKTOP-NR72F5K;Initial Catalog=quanlisangkien;Integrated Security=True";


        public bool openConnect()
        {
            try
            {
                con.ConnectionString = connectString;
                con.Open();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public void closeConnect()
        {
            con.Close();
        }

    }
}

