﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlisangkienMBF
{
    public partial class DKSK : Form
    {
        public DKSK()
        {
            InitializeComponent();
        }
        ConnectDB con = new ConnectDB();
        public void loadSangkien()
        {
            CRUD crud = new CRUD();
            string sql = "select * from sangkien";
            dataGridView1.DataSource = crud.getDataTable(sql);
        }
        void loadcmbdsk()
        {
            ConnectDB con = new ConnectDB();
            con.openConnect();
            string sql = "select * from dotsangkien ";
            var cmd = new SqlCommand(sql, con.con);
            var dr = cmd.ExecuteReader();
            var dt = new DataTable();
            dt.Load(dr);
            dr.Dispose();
            cmb_dotsk.DisplayMember = "madotsangkien";
            cmb_dotsk.ValueMember = "madotsangkien";
            cmb_dotsk.DataSource = dt;
            con.closeConnect();
        }
        void loadcmbcd()
        {
            ConnectDB con = new ConnectDB();
            con.openConnect();
            string sql = "select * from chudesangkien ";
            var cmd = new SqlCommand(sql, con.con);
            var dr = cmd.ExecuteReader();
            var dt = new DataTable();
            dt.Load(dr);
            dr.Dispose();
            cmb_cd.DisplayMember = "tenchude";
            cmb_cd.ValueMember = "machude";
            cmb_cd.DataSource = dt;
            con.closeConnect();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string msk = txt_msk.Text;
            string tensangkien = txt_tensk.Text;
            string mt = txt_muctieu.Text;
            string loiich = txt_loiich.Text;
            string doituong = txt_doituong.Text;
            string mdsk = cmb_dotsk.SelectedValue.ToString();
            string nd = txt_noidung.Text;
            string tt = "1";
            string cd = cmb_cd.SelectedValue.ToString();
            string dinhkem = txt_dk.Text;
            if (msk.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập mã sáng kiến");
                txt_msk.Focus();
            }
            else if (tensangkien.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập mật khẩu");
                txt_tensk.Focus();
            }
            else if (loiich.Trim() == "")
            {
                MessageBox.Show("Chưa có lợi ích của sáng kiến");
                txt_loiich.Focus();
            }
            else if (nd.Trim() == "")
            {
                MessageBox.Show("Chưa có nội dung của sáng kiến");
                txt_noidung.Focus();
            }

            else
            {
                try
                {
                    con.openConnect();
                    string sqlQuery = "INSERT INTO sangkien VALUES (@masangkien,@tensangkien,@madotsangkien,@muctieu,@noidung,@loiich,@doituong,@matrangthai,@dinhkem,@machude)";
                    SqlCommand cmd = new SqlCommand(sqlQuery, con.con);
                    cmd.Parameters.AddWithValue("masangkien", msk);
                    cmd.Parameters.AddWithValue("tensangkien", tensangkien);
                    cmd.Parameters.AddWithValue("madotsangkien", mdsk);
                    cmd.Parameters.AddWithValue("muctieu", mt);
                    cmd.Parameters.AddWithValue("noidung", nd);
                    cmd.Parameters.AddWithValue("loiich", loiich);
                    cmd.Parameters.AddWithValue("doituong", doituong);
                    cmd.Parameters.AddWithValue("matrangthai", tt);
                    cmd.Parameters.AddWithValue("dinhkem", dinhkem);
                    cmd.Parameters.AddWithValue("machude", cd);
                    cmd.ExecuteNonQuery();
                    con.closeConnect();
                    loadSangkien();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi không xác định", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void DKSK_Load(object sender, EventArgs e)
        {
            loadSangkien();
            loadcmbdsk();
            //loadcmbtt();
            loadcmbcd();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
