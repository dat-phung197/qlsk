﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace quanlisangkienMBF
{
    public partial class qlpb : Form
    {
        int quyen;
        public qlpb(int i)
        {
            InitializeComponent();
            quyen = i;
            if(quyen != 1)
            {
                btn_sua.Enabled = false;
                btn_them.Enabled = false;
                btn_xoa.Enabled = false;
            }
        }
        ConnectDB con = new ConnectDB();
        public void loadpb()
        {
            CRUD crud = new CRUD();
            string sqlQuery = "select * from Phongban";
            dataGridView1.DataSource = crud.getDataTable(sqlQuery);
        }

        private void qlpb_Load(object sender, EventArgs e)
        {
            loadpb();
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            con.openConnect();
            string sqlQuery = "INSERT INTO phongban VALUES (@maphongban,@tenphongban,@ngaythanhlap,@motaphongban)";
            SqlCommand cmd1 = new SqlCommand(sqlQuery, con.con);
            cmd1.Parameters.AddWithValue("maphongban", txt_ma.Text);
            cmd1.Parameters.AddWithValue("tenphongban", txt_Ten.Text);
            cmd1.Parameters.AddWithValue("ngaythanhlap", dateTimePicker1.Text);
            cmd1.Parameters.AddWithValue("motaphongban",txt_mota.Text);
            cmd1.ExecuteNonQuery();
            con.closeConnect();
            MessageBox.Show("Tạo Phòng ban thành công", "Thông báo");
            loadpb();
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            
            try
            {
                con.closeConnect();
                con.openConnect();
                string sqlEdit = "UPDATE phongban SET maphongban = @maphongban,tenphongban = @tenphongban,ngaythanhlap = @ngaythanhlap,motaphongban = @motaphongban WHERE maphongban = @maphongban";
                SqlCommand cmd1 = new SqlCommand(sqlEdit, con.con);
                cmd1.Parameters.AddWithValue("maphongban", txt_ma.Text);
                cmd1.Parameters.AddWithValue("tenphongban", txt_Ten.Text);
                cmd1.Parameters.AddWithValue("ngaythanhlap", dateTimePicker1.Text);
                cmd1.Parameters.AddWithValue("motaphongban", txt_mota.Text);
                cmd1.ExecuteNonQuery();
                con.closeConnect();
                loadpb();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chức vụ này đã tồn tại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                txt_ma.Text = row.Cells[0].Value.ToString();
                txt_Ten.Text = row.Cells[1].Value.ToString();
                txt_mota.Text = row.Cells[3].Value.ToString();
            }
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            try
            {

                con.closeConnect();
                con.openConnect();
                string sqlDelete = "DELETE FROM phongban WHERE maphongban = @maphongban";
                SqlCommand cmd1 = new SqlCommand(sqlDelete, con.con);
                cmd1.Parameters.AddWithValue("maphongban", txt_ma.Text);
                cmd1.Parameters.AddWithValue("tenphongban", txt_Ten.Text);
                cmd1.Parameters.AddWithValue("ngaythanhlap", dateTimePicker1.Text);
                cmd1.Parameters.AddWithValue("motaphongban", txt_mota.Text);
                cmd1.ExecuteNonQuery();
                con.closeConnect();
                loadpb();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Tên tài khoản đã tồn tại" + ex, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
