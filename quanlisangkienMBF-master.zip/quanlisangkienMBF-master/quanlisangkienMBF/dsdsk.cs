﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlisangkienMBF
{
    public partial class dsdsk : Form
    {
        int quyen;
        public dsdsk(int i)
        {
            quyen = i;
            InitializeComponent();
            if (quyen != 1)
            {
                btn_sua.Enabled = false;
                btn_them.Enabled = false;
                btn_xoa.Enabled = false;
            }
        }
        ConnectDB con = new ConnectDB();
        private void dsdsk_Load(object sender, EventArgs e)
        {
            loaddotsangkien();
        }

        private void dgv_dsk_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgv_dsk.Rows[e.RowIndex];
                txt_mdsk.Text = row.Cells[0].Value.ToString();
                txt_ten.Text = row.Cells[1].Value.ToString();
               /* dtp_nbd.Value = row.Cells[2].Value.ToString();
                dtp_nkt.Value = row.Cells[3].Value.ToString();
                dtp_handk.Text = row.Cells[4].Value.ToString();
                dtp_nkt.Text = row.Cells[5].Value.ToString(); */
            }
        }
        public void loaddotsangkien()
        {
            CRUD crud = new CRUD();
            string sql = "select * from dotsangkien";
            dgv_dsk.DataSource = crud.getDataTable(sql);
        }
        private void btn_them_Click(object sender, EventArgs e)
        {
            string mdsk = txt_mdsk.Text;
            string ten= txt_ten.Text;
            string nbd = dtp_nbd.Text;
            string nkt = dtp_nkt.Text;
            string hdk = dtp_handk.Text;
            string hnop = dtp_hnop.Text;
            if (mdsk.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập mã danh sách đợt sáng kiến");
                txt_mdsk.Focus();
            }
            else if (ten.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập tên đợt sáng kiến");
                txt_ten.Focus();
            }
            else
            {
                try
                {
                    con.openConnect();
                    string sqlQuery = "INSERT INTO dotsangkien VALUES (@madotsangkien,@tendotsangkien,@trangthai,@ngaybatdau,@ngayketthuc,@ngaydungdangky,@hannop)";
                    SqlCommand cmd = new SqlCommand(sqlQuery, con.con);
                    cmd.Parameters.AddWithValue("madotsangkien", mdsk);
                    cmd.Parameters.AddWithValue("tendotsangkien", ten);
                    cmd.Parameters.AddWithValue("trangthai","1");
                    cmd.Parameters.AddWithValue("ngaybatdau", nbd);
                    cmd.Parameters.AddWithValue("ngayketthuc", nkt);
                    cmd.Parameters.AddWithValue("ngaydungdangky",hdk);
                    cmd.Parameters.AddWithValue("hannop", hnop);
                    cmd.ExecuteNonQuery();
                    con.closeConnect();
                    loaddotsangkien();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi không xác định", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            string mdsk = txt_mdsk.Text;
            string ten = txt_ten.Text;
            string nbd = dtp_nbd.Text;
            string nkt = dtp_nkt.Text;
            string hdk = dtp_handk.Text;
            string hnop = dtp_hnop.Text;
            con.openConnect();
            string sqlQuery = "UPDATE dotsangkien SET tendotsangkien = @tendotsangkien,ngaybatdau = @ngaybatdau,ngayketthuc = @ngayketthuc,ngaydungdangky = @ngaydungdangky,hannop = @hannop  WHERE madotsangkien = @madotsangkien";
            SqlCommand cmd = new SqlCommand(sqlQuery, con.con);
            cmd.Parameters.AddWithValue("madotsangkien", mdsk);
            cmd.Parameters.AddWithValue("tendotsangkien", ten);
            cmd.Parameters.AddWithValue("ngaybatdau", nbd);
            cmd.Parameters.AddWithValue("ngayketthuc", nkt);
            cmd.Parameters.AddWithValue("ngaydungdangky", hdk);
            cmd.Parameters.AddWithValue("hannop", hnop);
            cmd.ExecuteNonQuery();
            con.closeConnect();
            loaddotsangkien();
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            string mdsk = txt_mdsk.Text;
            con.openConnect();
            string sqlDelete = "DELETE FROM dotsangkien WHERE madotsangkien = @madotsangkien";
            SqlCommand cmd1 = new SqlCommand(sqlDelete, con.con);
            cmd1.Parameters.AddWithValue("madotsangkien", mdsk);
            cmd1.ExecuteNonQuery();
            con.closeConnect();
            loaddotsangkien();
        }
    }
}
