﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace quanlisangkienMBF
{
    public partial class fNhanvien : Form
    {
        ConnectDB con = new ConnectDB();
        int quyen;
        public fNhanvien(int i)
        {
            InitializeComponent();
            quyen = i;
            if(quyen != 1)
            {
                btn_sua.Enabled = false;
                btn_them.Enabled = false;
                btn_xoa.Enabled = false;
                CRUD crud = new CRUD();
                string sqlQuery = "select * from view_nhanvien";
                dataGridView1.DataSource = crud.getDataTable(sqlQuery);
            }
            else
            {
                load1();
            }


        }
        public void load1()
        {
            CRUD crud = new CRUD();
            string sqlQuery = "select * from nhanvien";
            dataGridView1.DataSource = crud.getDataTable(sqlQuery);
        }

        private void btn_timkiem_Click(object sender, EventArgs e)
        {
            con.openConnect();
            string sqlQuery = "select * from view_nhanvien where  manhanvien = @manhanvien";
            SqlCommand cmd = new SqlCommand(sqlQuery, con.con);
            cmd.Parameters.AddWithValue("manhanvien", textBox1.Text);
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.closeConnect();
        }

        private void fNhanvien_Load(object sender, EventArgs e)
        {
            loadcombobox();
            loadcombobox1();
            loadcombobox2();
        }
        private void btn_them_Click(object sender, EventArgs e)
        {
            con.openConnect();
            string sqlQuery = "INSERT INTO nhanvien VALUES (@manhanvien,@maphongban,@machucvu,@tennhanvien,@matrinhdo,@gioitinh,@ngaysinh,@sdt,@ngayvaolam,@trangthai)";
            SqlCommand cmd1 = new SqlCommand(sqlQuery, con.con);
            cmd1.Parameters.AddWithValue("manhanvien", txt_mnv.Text);
            cmd1.Parameters.AddWithValue("maphongban", cmb_mpb.SelectedValue.ToString());
            cmd1.Parameters.AddWithValue("machucvu", cmb_mcv.SelectedValue.ToString());
            cmd1.Parameters.AddWithValue("tennhanvien", txt_ten.Text);
            cmd1.Parameters.AddWithValue("matrinhdo", cmb_td.SelectedValue.ToString());
            cmd1.Parameters.AddWithValue("gioitinh", cmb_gt.SelectedValue.ToString());
            cmd1.Parameters.AddWithValue("ngaysinh", dtp_ns.Text);
            cmd1.Parameters.AddWithValue("sdt", txt_sdt.Text);
            cmd1.Parameters.AddWithValue("ngayvaolam", dtp_ntg.Text);
            cmd1.Parameters.AddWithValue("trangthai", cmb_tt.SelectedValue.ToString());
            cmd1.ExecuteNonQuery();
            con.closeConnect();
            MessageBox.Show("Thêm nhân viên thành công", "Thông báo");
            load1();
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            try
            {
                con.closeConnect();
                con.openConnect();
                string sqlEdit = "UPDATE phongban SET maphongban = @maphongban,tenphongban = @tenphongban,ngaythanhlap = @ngaythanhlap,motaphongban = @motaphongban WHERE maphongban = @maphongban";
                SqlCommand cmd1 = new SqlCommand(sqlEdit, con.con);
                cmd1.Parameters.AddWithValue("manhanvien", txt_mnv.Text);
                cmd1.Parameters.AddWithValue("maphongban", cmb_mpb.SelectedValue.ToString());
                cmd1.Parameters.AddWithValue("machucvu", cmb_mcv.SelectedValue.ToString());
                cmd1.Parameters.AddWithValue("tennhanvien", txt_ten.Text);
                cmd1.Parameters.AddWithValue("matrinhdo", cmb_td.SelectedValue.ToString());
                cmd1.Parameters.AddWithValue("gioitinh", cmb_gt.SelectedValue.ToString());
                cmd1.Parameters.AddWithValue("ngaysinh", dtp_ns.Text);
                cmd1.Parameters.AddWithValue("sdt", txt_sdt.Text);
                cmd1.Parameters.AddWithValue("ngayvaolam", dtp_ntg.Text);
                cmd1.Parameters.AddWithValue("trangthai", cmb_tt.SelectedValue.ToString());
                cmd1.ExecuteNonQuery();
                con.closeConnect();
                load1();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            try
            {

                con.closeConnect();
                con.openConnect();
                string sqlDelete = "DELETE FROM nhanvien WHERE manhanvien = @manhanvien";
                SqlCommand cmd1 = new SqlCommand(sqlDelete, con.con);
                cmd1.Parameters.AddWithValue("manhanvien", txt_mnv.Text);
                cmd1.Parameters.AddWithValue("maphongban", cmb_mpb.SelectedValue.ToString());
                cmd1.Parameters.AddWithValue("machucvu", cmb_mcv.SelectedValue.ToString());
                cmd1.Parameters.AddWithValue("tennhanvien", txt_ten.Text);
                cmd1.Parameters.AddWithValue("matrinhdo", cmb_td.SelectedValue.ToString());
                cmd1.Parameters.AddWithValue("gioitinh", cmb_gt.SelectedValue.ToString());
                cmd1.Parameters.AddWithValue("ngaysinh", dtp_ns.Text);
                cmd1.Parameters.AddWithValue("sdt", txt_sdt.Text);
                cmd1.Parameters.AddWithValue("ngayvaolam", dtp_ntg.Text);
                cmd1.Parameters.AddWithValue("trangthai", cmb_tt.SelectedValue.ToString());
                cmd1.ExecuteNonQuery();
                con.closeConnect();
                load1();
            }
            catch (Exception ex)
            {
                MessageBox.Show("xảy ra lỗi" + ex, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (quyen != 1)
            {
                CRUD crud = new CRUD();
                string sqlQuery = "select * from view_nhanvien";
                dataGridView1.DataSource = crud.getDataTable(sqlQuery);
            }
            else
            {
                CRUD crud = new CRUD();
                string sqlQuery = "select * from nhanvien";
                dataGridView1.DataSource = crud.getDataTable(sqlQuery);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                txt_mnv.Text = row.Cells[0].Value.ToString();
              //  cmb_mpb.ValueMember = row.Cells[1].Value.ToString();
               // cmb_mpb.DisplayMember = row.Cells[1].Value.ToString();
              //  cmb_mcv.DisplayMember = row.Cells[2].Value.ToString();
             //   cmb_mcv.ValueMember = row.Cells[2].Value.ToString();
                txt_ten.Text = row.Cells[3].Value.ToString();
             //   cmb_td.DisplayMember = row.Cells[4].Value.ToString();
             //   cmb_td.ValueMember = row.Cells[4].Value.ToString();
              //  cmb_gt.ValueMember = row.Cells[5].Value.ToString();
          //      cmb_gt.ValueMember = row.Cells[5].Value.ToString();
                txt_sdt.Text = row.Cells[7].Value.ToString();
              //  cmb_tt.Text = row.Cells[9].Value.ToString();
            }
        }
        public void loadcombobox()
        {
            ConnectDB con = new ConnectDB();
            con.openConnect();
            string sql = "select * from phongban";
            var cmd = new SqlCommand(sql, con.con);
            var dr = cmd.ExecuteReader();
            var dt = new DataTable();
            dt.Load(dr);
            dr.Dispose();
            cmb_mpb.DisplayMember = "maphongban";
            cmb_mpb.ValueMember = "maphongban";
            cmb_mpb.DataSource = dt;
            con.closeConnect();
        }
        public void loadcombobox1()
        {
            ConnectDB con = new ConnectDB();
            con.openConnect();
            string sql = "select * from chucvu";
            var cmd = new SqlCommand(sql, con.con);
            var dr = cmd.ExecuteReader();
            var dt = new DataTable();
            dt.Load(dr);
            dr.Dispose();
            cmb_mcv.DisplayMember = "machucvu";
            cmb_mcv.ValueMember = "machucvu";
            cmb_mcv.DataSource = dt;
            con.closeConnect();
        }
        public void loadcombobox2()
        {
            ConnectDB con = new ConnectDB();
            con.openConnect();
            string sql = "select * from trinhdo ";
            var cmd = new SqlCommand(sql, con.con);
            var dr = cmd.ExecuteReader();
            var dt = new DataTable();
            dt.Load(dr);
            dr.Dispose();
            cmb_td.DisplayMember = "matrinhdo";
            cmb_td.ValueMember = "matrinhdo";
            cmb_td.DataSource = dt;
            con.closeConnect();
        }
    }
}
