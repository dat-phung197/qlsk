﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlisangkienMBF
{
    public partial class addAccount : Form
    {
        public addAccount()
        {


            InitializeComponent();
        }
        void loadcombobox() { 
        ConnectDB con = new ConnectDB();
        con.openConnect();
        string sql = "select * from quyen ";
        var cmd = new SqlCommand(sql, con.con);
        var dr = cmd.ExecuteReader();
        var dt = new DataTable();
        dt.Load(dr);
            dr.Dispose();
            comboBox1.DisplayMember = "tenquyen";
            comboBox1.ValueMember = "maquyen";
            comboBox1.DataSource = dt;

        con.closeConnect();
        }


        private void addAccount_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'quanlisangkienDataSet.nhanvien' table. You can move, or remove it, as needed.
            this.nhanvienTableAdapter.Fill(this.quanlisangkienDataSet.nhanvien);
        }
    }
}
