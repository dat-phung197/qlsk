﻿namespace quanlisangkienMBF
{
    partial class fMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.dgv_tvhd = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lb_hannopbaocao = new System.Windows.Forms.Label();
            this.lb_handangky = new System.Windows.Forms.Label();
            this.lb_ngayketthuc = new System.Windows.Forms.Label();
            this.lb_ngaybatdau = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lb_phongban = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_chucvu = new System.Windows.Forms.Label();
            this.txt_ten = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ghToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLíXếpLoạiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLíTrạngTháiSángKiếnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLíNhânViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLíĐợtSángKiếnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLiSángKiếnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_dk = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_myidea = new System.Windows.Forms.ToolStripMenuItem();
            this.duyet_menu = new System.Windows.Forms.ToolStripMenuItem();
            this.chamdiem_menu = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảXếpLoạiSángKiếnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.khenThưởngSángKiếnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảKhenThưởngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.fgToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fgToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fgToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.admin_menu = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmTàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cậpNhậpSángKiếnMớiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cậpNhậpPhòngBanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLíChứcVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLíĐợtSángKiếnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_tvhd)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.menuStrip1);
            this.panel1.Location = new System.Drawing.Point(1, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(874, 562);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.dgv_tvhd);
            this.panel4.Location = new System.Drawing.Point(304, 271);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(569, 286);
            this.panel4.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(199, 38);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(178, 24);
            this.label9.TabIndex = 2;
            this.label9.Text = "Hội đồng khoa học";
            // 
            // dgv_tvhd
            // 
            this.dgv_tvhd.AllowUserToAddRows = false;
            this.dgv_tvhd.AllowUserToDeleteRows = false;
            this.dgv_tvhd.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_tvhd.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_tvhd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_tvhd.Location = new System.Drawing.Point(6, 65);
            this.dgv_tvhd.Name = "dgv_tvhd";
            this.dgv_tvhd.ReadOnly = true;
            this.dgv_tvhd.Size = new System.Drawing.Size(545, 221);
            this.dgv_tvhd.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gray;
            this.panel3.Controls.Add(this.lb_hannopbaocao);
            this.panel3.Controls.Add(this.lb_handangky);
            this.panel3.Controls.Add(this.lb_ngayketthuc);
            this.panel3.Controls.Add(this.lb_ngaybatdau);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Location = new System.Drawing.Point(304, 81);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(551, 133);
            this.panel3.TabIndex = 3;
            // 
            // lb_hannopbaocao
            // 
            this.lb_hannopbaocao.AutoSize = true;
            this.lb_hannopbaocao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_hannopbaocao.Location = new System.Drawing.Point(422, 85);
            this.lb_hannopbaocao.Name = "lb_hannopbaocao";
            this.lb_hannopbaocao.Size = new System.Drawing.Size(126, 16);
            this.lb_hannopbaocao.TabIndex = 8;
            this.lb_hannopbaocao.Text = "Hạn nộp báo cáo";
            // 
            // lb_handangky
            // 
            this.lb_handangky.AutoSize = true;
            this.lb_handangky.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_handangky.Location = new System.Drawing.Point(287, 85);
            this.lb_handangky.Name = "lb_handangky";
            this.lb_handangky.Size = new System.Drawing.Size(100, 16);
            this.lb_handangky.TabIndex = 7;
            this.lb_handangky.Text = "Ngày bắt đầu";
            // 
            // lb_ngayketthuc
            // 
            this.lb_ngayketthuc.AutoSize = true;
            this.lb_ngayketthuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ngayketthuc.Location = new System.Drawing.Point(155, 85);
            this.lb_ngayketthuc.Name = "lb_ngayketthuc";
            this.lb_ngayketthuc.Size = new System.Drawing.Size(100, 16);
            this.lb_ngayketthuc.TabIndex = 6;
            this.lb_ngayketthuc.Text = "Ngày bắt đầu";
            // 
            // lb_ngaybatdau
            // 
            this.lb_ngaybatdau.AutoSize = true;
            this.lb_ngaybatdau.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ngaybatdau.Location = new System.Drawing.Point(22, 85);
            this.lb_ngaybatdau.Name = "lb_ngaybatdau";
            this.lb_ngaybatdau.Size = new System.Drawing.Size(100, 16);
            this.lb_ngaybatdau.TabIndex = 5;
            this.lb_ngaybatdau.Text = "Ngày bắt đầu";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(422, 49);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(126, 16);
            this.label8.TabIndex = 4;
            this.label8.Text = "Hạn nộp báo cáo";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(287, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 16);
            this.label7.TabIndex = 3;
            this.label7.Text = "Hạn đăng kí";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(154, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Ngày kết thúc";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(22, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Ngày bắt đầu";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(170, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Thông báo đợt sáng kiến";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.lb_phongban);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.lb_chucvu);
            this.panel2.Controls.Add(this.txt_ten);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(3, 80);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(285, 481);
            this.panel2.TabIndex = 1;
            // 
            // lb_phongban
            // 
            this.lb_phongban.AutoSize = true;
            this.lb_phongban.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_phongban.Location = new System.Drawing.Point(43, 295);
            this.lb_phongban.Name = "lb_phongban";
            this.lb_phongban.Size = new System.Drawing.Size(90, 21);
            this.lb_phongban.TabIndex = 5;
            this.lb_phongban.Text = "Phòng ban";
            this.lb_phongban.AutoSizeChanged += new System.EventHandler(this.fMain_Load);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(16, 261);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 21);
            this.label4.TabIndex = 4;
            this.label4.Text = "Phòng ban";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(251, 19);
            this.label3.TabIndex = 3;
            this.label3.Text = "Công ty dịch vụ Mobifone khu vực 5";
            // 
            // lb_chucvu
            // 
            this.lb_chucvu.AutoSize = true;
            this.lb_chucvu.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_chucvu.Location = new System.Drawing.Point(119, 191);
            this.lb_chucvu.Name = "lb_chucvu";
            this.lb_chucvu.Size = new System.Drawing.Size(74, 21);
            this.lb_chucvu.TabIndex = 2;
            this.lb_chucvu.Text = "Chức vụ";
            // 
            // txt_ten
            // 
            this.txt_ten.BackColor = System.Drawing.Color.Gray;
            this.txt_ten.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ten.Location = new System.Drawing.Point(20, 136);
            this.txt_ten.Name = "txt_ten";
            this.txt_ten.Size = new System.Drawing.Size(247, 39);
            this.txt_ten.TabIndex = 1;
            this.txt_ten.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 191);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Chức vụ";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem3,
            this.admin_menu});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(872, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ghToolStripMenuItem,
            this.quảnLíXếpLoạiToolStripMenuItem,
            this.quảnLíTrạngTháiSángKiếnToolStripMenuItem,
            this.quảnLíNhânViênToolStripMenuItem,
            this.quảnLíĐợtSángKiếnToolStripMenuItem,
            this.quảnLiSángKiếnToolStripMenuItem,
            this.menu_dk,
            this.menu_myidea,
            this.duyet_menu,
            this.chamdiem_menu,
            this.tấtCảXếpLoạiSángKiếnToolStripMenuItem,
            this.khenThưởngSángKiếnToolStripMenuItem,
            this.tấtCảKhenThưởngToolStripMenuItem});
            this.toolStripMenuItem1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(131, 23);
            this.toolStripMenuItem1.Text = "Quản lí thông tin";
            // 
            // ghToolStripMenuItem
            // 
            this.ghToolStripMenuItem.Name = "ghToolStripMenuItem";
            this.ghToolStripMenuItem.Size = new System.Drawing.Size(286, 24);
            this.ghToolStripMenuItem.Text = "Danh sách phòng ban";
            this.ghToolStripMenuItem.Click += new System.EventHandler(this.ghToolStripMenuItem_Click);
            // 
            // quảnLíXếpLoạiToolStripMenuItem
            // 
            this.quảnLíXếpLoạiToolStripMenuItem.Name = "quảnLíXếpLoạiToolStripMenuItem";
            this.quảnLíXếpLoạiToolStripMenuItem.Size = new System.Drawing.Size(286, 24);
            this.quảnLíXếpLoạiToolStripMenuItem.Text = "Thành viên hội đồng qua các kì";
            this.quảnLíXếpLoạiToolStripMenuItem.Click += new System.EventHandler(this.quảnLíXếpLoạiToolStripMenuItem_Click);
            // 
            // quảnLíTrạngTháiSángKiếnToolStripMenuItem
            // 
            this.quảnLíTrạngTháiSángKiếnToolStripMenuItem.Name = "quảnLíTrạngTháiSángKiếnToolStripMenuItem";
            this.quảnLíTrạngTháiSángKiếnToolStripMenuItem.Size = new System.Drawing.Size(286, 24);
            this.quảnLíTrạngTháiSángKiếnToolStripMenuItem.Text = "Danh sách chức vụ";
            this.quảnLíTrạngTháiSángKiếnToolStripMenuItem.Click += new System.EventHandler(this.quảnLíTrạngTháiSángKiếnToolStripMenuItem_Click);
            // 
            // quảnLíNhânViênToolStripMenuItem
            // 
            this.quảnLíNhânViênToolStripMenuItem.Name = "quảnLíNhânViênToolStripMenuItem";
            this.quảnLíNhânViênToolStripMenuItem.Size = new System.Drawing.Size(286, 24);
            this.quảnLíNhânViênToolStripMenuItem.Text = "Danh sách nhân viên";
            this.quảnLíNhânViênToolStripMenuItem.Click += new System.EventHandler(this.quảnLíNhânViênToolStripMenuItem_Click);
            // 
            // quảnLíĐợtSángKiếnToolStripMenuItem
            // 
            this.quảnLíĐợtSángKiếnToolStripMenuItem.Name = "quảnLíĐợtSángKiếnToolStripMenuItem";
            this.quảnLíĐợtSángKiếnToolStripMenuItem.Size = new System.Drawing.Size(286, 24);
            this.quảnLíĐợtSángKiếnToolStripMenuItem.Text = "Danh sách đợt sáng kiến";
            this.quảnLíĐợtSángKiếnToolStripMenuItem.Click += new System.EventHandler(this.quảnLíĐợtSángKiếnToolStripMenuItem_Click);
            // 
            // quảnLiSángKiếnToolStripMenuItem
            // 
            this.quảnLiSángKiếnToolStripMenuItem.Name = "quảnLiSángKiếnToolStripMenuItem";
            this.quảnLiSángKiếnToolStripMenuItem.Size = new System.Drawing.Size(286, 24);
            this.quảnLiSángKiếnToolStripMenuItem.Text = "Danh sách sáng kiến kì hiện tại";
            this.quảnLiSángKiếnToolStripMenuItem.Click += new System.EventHandler(this.quảnLiSángKiếnToolStripMenuItem_Click);
            // 
            // menu_dk
            // 
            this.menu_dk.Name = "menu_dk";
            this.menu_dk.Size = new System.Drawing.Size(286, 24);
            this.menu_dk.Text = "Đăng ký sáng kiến";
            this.menu_dk.Click += new System.EventHandler(this.đăngKýSángKiếnToolStripMenuItem_Click);
            // 
            // menu_myidea
            // 
            this.menu_myidea.Name = "menu_myidea";
            this.menu_myidea.Size = new System.Drawing.Size(286, 24);
            this.menu_myidea.Text = "Sáng kiến của tôi";
            this.menu_myidea.Click += new System.EventHandler(this.menu_myidea_Click);
            // 
            // duyet_menu
            // 
            this.duyet_menu.Name = "duyet_menu";
            this.duyet_menu.Size = new System.Drawing.Size(286, 24);
            this.duyet_menu.Text = "Duyệt sáng kiến";
            this.duyet_menu.Click += new System.EventHandler(this.duyet_menu_Click);
            // 
            // chamdiem_menu
            // 
            this.chamdiem_menu.Name = "chamdiem_menu";
            this.chamdiem_menu.Size = new System.Drawing.Size(286, 24);
            this.chamdiem_menu.Text = "Chấm điểm";
            this.chamdiem_menu.Click += new System.EventHandler(this.chamdiem_menu_Click);
            // 
            // tấtCảXếpLoạiSángKiếnToolStripMenuItem
            // 
            this.tấtCảXếpLoạiSángKiếnToolStripMenuItem.Name = "tấtCảXếpLoạiSángKiếnToolStripMenuItem";
            this.tấtCảXếpLoạiSángKiếnToolStripMenuItem.Size = new System.Drawing.Size(286, 24);
            this.tấtCảXếpLoạiSángKiếnToolStripMenuItem.Text = "Tất cả xếp loại sáng kiến";
            // 
            // khenThưởngSángKiếnToolStripMenuItem
            // 
            this.khenThưởngSángKiếnToolStripMenuItem.Name = "khenThưởngSángKiếnToolStripMenuItem";
            this.khenThưởngSángKiếnToolStripMenuItem.Size = new System.Drawing.Size(286, 24);
            this.khenThưởngSángKiếnToolStripMenuItem.Text = "Khen thưởng sáng kiến";
            // 
            // tấtCảKhenThưởngToolStripMenuItem
            // 
            this.tấtCảKhenThưởngToolStripMenuItem.Name = "tấtCảKhenThưởngToolStripMenuItem";
            this.tấtCảKhenThưởngToolStripMenuItem.Size = new System.Drawing.Size(286, 24);
            this.tấtCảKhenThưởngToolStripMenuItem.Text = "Tất cả khen thưởng";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fgToolStripMenuItem,
            this.fgToolStripMenuItem1,
            this.fgToolStripMenuItem2});
            this.toolStripMenuItem3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(102, 23);
            this.toolStripMenuItem3.Text = "My Account";
            // 
            // fgToolStripMenuItem
            // 
            this.fgToolStripMenuItem.Name = "fgToolStripMenuItem";
            this.fgToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.fgToolStripMenuItem.Text = "Đổi mật khẩu";
            // 
            // fgToolStripMenuItem1
            // 
            this.fgToolStripMenuItem1.Name = "fgToolStripMenuItem1";
            this.fgToolStripMenuItem1.Size = new System.Drawing.Size(168, 24);
            this.fgToolStripMenuItem1.Text = "Đăng xuất";
            this.fgToolStripMenuItem1.Click += new System.EventHandler(this.fgToolStripMenuItem1_Click);
            // 
            // fgToolStripMenuItem2
            // 
            this.fgToolStripMenuItem2.Name = "fgToolStripMenuItem2";
            this.fgToolStripMenuItem2.Size = new System.Drawing.Size(168, 24);
            this.fgToolStripMenuItem2.Text = "Thoát";
            this.fgToolStripMenuItem2.Click += new System.EventHandler(this.fgToolStripMenuItem2_Click);
            // 
            // admin_menu
            // 
            this.admin_menu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thêmTàiKhoảnToolStripMenuItem,
            this.cậpNhậpSángKiếnMớiToolStripMenuItem,
            this.cậpNhậpPhòngBanToolStripMenuItem,
            this.quảnLíChứcVụToolStripMenuItem,
            this.quảnLíĐợtSángKiếnToolStripMenuItem1});
            this.admin_menu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.admin_menu.Name = "admin_menu";
            this.admin_menu.Size = new System.Drawing.Size(78, 23);
            this.admin_menu.Text = "ADMIN";
            // 
            // thêmTàiKhoảnToolStripMenuItem
            // 
            this.thêmTàiKhoảnToolStripMenuItem.Name = "thêmTàiKhoảnToolStripMenuItem";
            this.thêmTàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(198, 24);
            this.thêmTàiKhoảnToolStripMenuItem.Text = "Thêm tài khoản";
            this.thêmTàiKhoảnToolStripMenuItem.Click += new System.EventHandler(this.thêmTàiKhoảnToolStripMenuItem_Click);
            // 
            // cậpNhậpSángKiếnMớiToolStripMenuItem
            // 
            this.cậpNhậpSángKiếnMớiToolStripMenuItem.Name = "cậpNhậpSángKiếnMớiToolStripMenuItem";
            this.cậpNhậpSángKiếnMớiToolStripMenuItem.Size = new System.Drawing.Size(198, 24);
            this.cậpNhậpSángKiếnMớiToolStripMenuItem.Text = "Quản lí sáng kiến";
            this.cậpNhậpSángKiếnMớiToolStripMenuItem.Click += new System.EventHandler(this.cậpNhậpSángKiếnMớiToolStripMenuItem_Click);
            // 
            // cậpNhậpPhòngBanToolStripMenuItem
            // 
            this.cậpNhậpPhòngBanToolStripMenuItem.Name = "cậpNhậpPhòngBanToolStripMenuItem";
            this.cậpNhậpPhòngBanToolStripMenuItem.Size = new System.Drawing.Size(198, 24);
            this.cậpNhậpPhòngBanToolStripMenuItem.Text = "Quản lí phòng ban";
            this.cậpNhậpPhòngBanToolStripMenuItem.Click += new System.EventHandler(this.cậpNhậpPhòngBanToolStripMenuItem_Click);
            // 
            // quảnLíChứcVụToolStripMenuItem
            // 
            this.quảnLíChứcVụToolStripMenuItem.Name = "quảnLíChứcVụToolStripMenuItem";
            this.quảnLíChứcVụToolStripMenuItem.Size = new System.Drawing.Size(198, 24);
            this.quảnLíChứcVụToolStripMenuItem.Text = "Quản lí chức vụ";
            this.quảnLíChứcVụToolStripMenuItem.Click += new System.EventHandler(this.quảnLíChứcVụToolStripMenuItem_Click);
            // 
            // quảnLíĐợtSángKiếnToolStripMenuItem1
            // 
            this.quảnLíĐợtSángKiếnToolStripMenuItem1.Name = "quảnLíĐợtSángKiếnToolStripMenuItem1";
            this.quảnLíĐợtSángKiếnToolStripMenuItem1.Size = new System.Drawing.Size(220, 24);
            this.quảnLíĐợtSángKiếnToolStripMenuItem1.Text = "Quản lí đợt sáng kiến";
            this.quảnLíĐợtSángKiếnToolStripMenuItem1.Click += new System.EventHandler(this.quảnLíĐợtSángKiếnToolStripMenuItem1_Click);
            // 
            // fMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(881, 562);
            this.Controls.Add(this.panel1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fMain";
            this.Text = "Trang chủ";
            this.Load += new System.EventHandler(this.fMain_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_tvhd)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dgv_tvhd;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lb_hannopbaocao;
        private System.Windows.Forms.Label lb_handangky;
        private System.Windows.Forms.Label lb_ngayketthuc;
        private System.Windows.Forms.Label lb_ngaybatdau;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lb_phongban;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_chucvu;
        private System.Windows.Forms.TextBox txt_ten;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ghToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem fgToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fgToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fgToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem quảnLíXếpLoạiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLíTrạngTháiSángKiếnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLíNhânViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLíĐợtSángKiếnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLiSángKiếnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menu_dk;
        private System.Windows.Forms.ToolStripMenuItem menu_myidea;
        private System.Windows.Forms.ToolStripMenuItem duyet_menu;
        private System.Windows.Forms.ToolStripMenuItem chamdiem_menu;
        private System.Windows.Forms.ToolStripMenuItem tấtCảXếpLoạiSángKiếnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem khenThưởngSángKiếnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tấtCảKhenThưởngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem admin_menu;
        private System.Windows.Forms.ToolStripMenuItem thêmTàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cậpNhậpSángKiếnMớiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cậpNhậpPhòngBanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLíChứcVụToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLíĐợtSángKiếnToolStripMenuItem1;
    }
}