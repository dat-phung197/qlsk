﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace quanlisangkienMBF
{
    
    public partial class addsangkien : Form
    {
        ConnectDB con = new ConnectDB();
        public addsangkien()
        {
            InitializeComponent();
        }
        public void loadSangkien()
        {
            CRUD crud = new CRUD();
            string sql = "select * from sangkien";
            dataGridView1.DataSource = crud.getDataTable(sql);
            string sql1 = "select * from sangkien where matrangthai = 1";
            dgv_skpd.DataSource = crud.getDataTable(sql1);
            string sql2 = "select * from sangkien where matrangthai = 4";
            dgv_skbl.DataSource = crud.getDataTable(sql2);
        }
        void loadcmbdsk()
        {
            ConnectDB con = new ConnectDB();
            con.openConnect();
            string sql = "select * from dotsangkien ";
            var cmd = new SqlCommand(sql, con.con);
            var dr = cmd.ExecuteReader();
            var dt = new DataTable();
            dt.Load(dr);
            dr.Dispose();
            cmb_dotsk.DisplayMember = "madotsangkien";
            cmb_dotsk.ValueMember = "madotsangkien";
            cmb_dotsk.DataSource = dt;
            con.closeConnect();
        }
       void loadcmbcd()
        {
            ConnectDB con = new ConnectDB();
            con.openConnect();
            string sql = "select * from chudesangkien ";
            var cmd = new SqlCommand(sql, con.con);
            var dr = cmd.ExecuteReader();
            var dt = new DataTable();
            dt.Load(dr);
            dr.Dispose();
            cmb_cd.DisplayMember = "tenchude";
            cmb_cd.ValueMember = "machude";
            cmb_cd.DataSource = dt;
            con.closeConnect();
        }
     /*   void loadcmbtt()
        {
            ConnectDB con = new ConnectDB();
            con.openConnect();
            string sql = "select * from trangthaisangkien";
            var cmd = new SqlCommand(sql, con.con);
            var dr = cmd.ExecuteReader();
            var dt = new DataTable();
            dt.Load(dr);
            dr.Dispose();
            cmb_tt.DisplayMember = "tentrangthai";
            cmb_tt.ValueMember = "matrangthai";
            cmb_tt.DataSource = dt;
            //
            con.closeConnect();
        } */
        private void addsangkien_Load(object sender, EventArgs e)
        {
            loadSangkien();
            loadcmbdsk();
            //loadcmbtt();
            loadcmbcd();
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            try
            {
                string msk = txt_msk.Text;
                string tensangkien = txt_tensk.Text;
                string mt = txt_muctieu.Text;
                string loiich = txt_loiich.Text;
                string doituong = txt_doituong.Text;
                string mdsk = cmb_dotsk.SelectedValue.ToString();
                string nd = txt_noidung.Text;
                string tt = "1";
                string cd = cmb_cd.SelectedValue.ToString();
                string dinhkem = txt_dk.Text;
                con.openConnect();
                string sqlQuery = "UPDATE sangkien SET tensangkien = @tensangkien,madotsangkien = @madotsangkien,muctieu = @muctieu,noidung = @noidung,loiich = @loiich,doituong = @doituong,dinhkem = @dinhkem,machude = @machude WHERE masangkien = @masangkien";
                SqlCommand cmd = new SqlCommand(sqlQuery, con.con);
                cmd.Parameters.AddWithValue("masangkien", msk);
                cmd.Parameters.AddWithValue("tensangkien", tensangkien);
                cmd.Parameters.AddWithValue("madotsangkien", mdsk);
                cmd.Parameters.AddWithValue("muctieu", mt);
                cmd.Parameters.AddWithValue("noidung", nd);
                cmd.Parameters.AddWithValue("loiich", loiich);
                cmd.Parameters.AddWithValue("doituong", doituong);
                //cmd.Parameters.AddWithValue("matrangthai", tt);
                cmd.Parameters.AddWithValue("dinhkem", dinhkem);
                cmd.Parameters.AddWithValue("machude", cd);
                cmd.ExecuteNonQuery();
                con.closeConnect();
                loadSangkien();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Tên tài khoản đã tồn tại" + ex, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void btn_xoa_Click(object sender, EventArgs e)
        {
            try
            {
                string msk = txt_msk.Text;
                con.openConnect();
                string sqlDelete = "DELETE FROM sangkien WHERE masangkien = @masangkien";
                SqlCommand cmd1 = new SqlCommand(sqlDelete, con.con);
                cmd1.Parameters.AddWithValue("masangkien", msk.ToString());
                cmd1.ExecuteNonQuery();
                con.closeConnect();
                loadSangkien();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Loi khong xac dinh" , "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string msk = txt_msk.Text;
            string tensangkien = txt_tensk.Text;
            string mt = txt_muctieu.Text;
            string loiich = txt_loiich.Text;
            string doituong = txt_doituong.Text;
            string mdsk = cmb_dotsk.SelectedValue.ToString();
            string nd = txt_noidung.Text;
            string tt = "1";
            string cd = cmb_cd.SelectedValue.ToString();
            string dinhkem = txt_dk.Text;
            if (msk.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập mã sáng kiến");
                txt_msk.Focus();
            }
            else if (tensangkien.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập mật khẩu");
                txt_tensk.Focus();
            }
            else if (loiich.Trim() == "")
            {
                MessageBox.Show("Chưa có lợi ích của sáng kiến");
                txt_loiich.Focus();
            }
            else if (nd.Trim() == "")
            {
                MessageBox.Show("Chưa có nội dung của sáng kiến");
                txt_noidung.Focus();
            }
            else
            {
                try
                {
                    con.openConnect();
                    string sqlQuery = "INSERT INTO sangkien VALUES (@masangkien,@tensangkien,@madotsangkien,@muctieu,@noidung,@loiich,@doituong,@matrangthai,@dinhkem,@machude)";
                    SqlCommand cmd = new SqlCommand(sqlQuery, con.con);
                    cmd.Parameters.AddWithValue("masangkien", msk);
                    cmd.Parameters.AddWithValue("tensangkien", tensangkien);
                    cmd.Parameters.AddWithValue("madotsangkien", mdsk);
                    cmd.Parameters.AddWithValue("muctieu", mt);
                    cmd.Parameters.AddWithValue("noidung", nd);
                    cmd.Parameters.AddWithValue("loiich", loiich);
                    cmd.Parameters.AddWithValue("doituong", doituong);
                    cmd.Parameters.AddWithValue("matrangthai", tt);
                    cmd.Parameters.AddWithValue("dinhkem", dinhkem);
                    cmd.Parameters.AddWithValue("machude", cd);
                    cmd.ExecuteNonQuery();
                    con.closeConnect();
                    loadSangkien();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi không xác định", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }



        private void btn_duyet_Click(object sender, EventArgs e)
        {
            try
            {
                string msk = txt_msk.Text;
                string tt = "2";
                con.openConnect();
                string sqlQuery = "UPDATE sangkien SET matrangthai = @matrangthai WHERE masangkien = @masangkien";
                SqlCommand cmd = new SqlCommand(sqlQuery, con.con);
                cmd.Parameters.AddWithValue("masangkien", msk);
                cmd.Parameters.AddWithValue("matrangthai", tt);
                cmd.ExecuteNonQuery();
                con.closeConnect();
                loadSangkien();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Tên tài khoản đã tồn tại" + ex, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn_tuchoi_Click(object sender, EventArgs e)
        {
            try
            {
                string msk = txt_msk.Text;
                string tt = "4";
                con.openConnect();
                string sqlQuery = "UPDATE sangkien SET matrangthai = @matrangthai WHERE masangkien = @masangkien";
                SqlCommand cmd = new SqlCommand(sqlQuery, con.con);
                cmd.Parameters.AddWithValue("masangkien", msk);
                cmd.Parameters.AddWithValue("matrangthai", tt);
                cmd.ExecuteNonQuery();
                con.closeConnect();
                loadSangkien();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi bất định", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                txt_msk.Text = row.Cells[0].Value.ToString();
                txt_tensk.Text = row.Cells[1].Value.ToString();
                cmb_dotsk.Text = row.Cells[2].Value.ToString();
                txt_muctieu.Text = row.Cells[3].Value.ToString();
                txt_noidung.Text = row.Cells[4].Value.ToString();
                txt_loiich.Text = row.Cells[5].Value.ToString();
                txt_doituong.Text = row.Cells[6].Value.ToString();
                txt_tt.Text = row.Cells[7].Value.ToString();
                txt_dk.Text = row.Cells[8].Value.ToString();
                cmb_cd.Text = row.Cells[9].Value.ToString();
            }
        }

        private void dgv_skpd_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgv_skpd.Rows[e.RowIndex];
                txt_msk.Text = row.Cells[0].Value.ToString();
                txt_tensk.Text = row.Cells[1].Value.ToString();
                cmb_dotsk.Text = row.Cells[2].Value.ToString();
                txt_muctieu.Text = row.Cells[3].Value.ToString();
                txt_noidung.Text = row.Cells[4].Value.ToString();
                txt_loiich.Text = row.Cells[5].Value.ToString();
                txt_doituong.Text = row.Cells[6].Value.ToString();
                txt_tt.Text = row.Cells[7].Value.ToString();
                txt_dk.Text = row.Cells[8].Value.ToString();
                cmb_cd.Text = row.Cells[9].Value.ToString();
            }
        }

        private void dgv_skbl_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgv_skbl.Rows[e.RowIndex];
                txt_msk.Text = row.Cells[0].Value.ToString();
                txt_tensk.Text = row.Cells[1].Value.ToString();
                cmb_dotsk.Text = row.Cells[2].Value.ToString();
                txt_muctieu.Text = row.Cells[3].Value.ToString();
                txt_noidung.Text = row.Cells[4].Value.ToString();
                txt_loiich.Text = row.Cells[5].Value.ToString();
                txt_doituong.Text = row.Cells[6].Value.ToString();
                txt_tt.Text = row.Cells[7].Value.ToString();
                txt_dk.Text = row.Cells[8].Value.ToString();
                cmb_cd.Text = row.Cells[9].Value.ToString();
            }
        }
    }
}
