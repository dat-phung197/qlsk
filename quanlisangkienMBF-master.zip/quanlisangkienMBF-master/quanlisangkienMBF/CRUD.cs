﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace quanlisangkienMBF
{
    public class CRUD
    {
        public DataTable getDataTable(string sqlQuery)
        {
            ConnectDB con = new ConnectDB();
            try
            {
                con.openConnect();
                DataSet dataSet = new DataSet();
                SqlCommand command = new SqlCommand(sqlQuery, con.con);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dataSet);
                DataTable dataTable = dataSet.Tables[0];
                con.closeConnect();
                return dataTable;
            }
            catch
            {
                return null;
            }
        }
       public SqlDataReader getData(string sqlQuery)
        {
            ConnectDB con = new ConnectDB();
            con.openConnect();
            SqlDataReader dulieu;
            SqlCommand cmd = new SqlCommand(sqlQuery,con.con);
            dulieu = cmd.ExecuteReader();
            return dulieu;
        }
        public bool execSqlQuery(string sqlQuery)
        {
            ConnectDB con = new ConnectDB();
            try
            {
                con.openConnect();
                SqlCommand command = new SqlCommand(sqlQuery, con.con);
                command.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
        }

    }
}
