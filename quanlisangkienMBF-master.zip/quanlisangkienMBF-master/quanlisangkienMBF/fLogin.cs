﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlisangkienMBF
{
    public partial class fLogin : Form
    {
        ConnectDB con = new ConnectDB();
        public fLogin()
        {
            InitializeComponent();
        }

        private void btn_thoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_dangnhap_Click(object sender, EventArgs e)
        {
            SqlDataReader dulieu;
            try
            {
                con.openConnect();

                string tk = txt_tk.Text;
                string mk = txt_mk.Text;
                if (tk.Trim() == "")
                {
                    MessageBox.Show("Vui lòng nhập tên tài khoản");
                }
                else if (mk.Trim() == "")
                {
                    MessageBox.Show("Vui lòng nhập mật khẩu");
                }
                else
                {
                    string sql = "select * from view_tk Where tentaikhoan = '" + tk + "' and matkhau = '" + mk + "' ";
                    SqlCommand cmd = new SqlCommand(sql,con.con);
                    dulieu = cmd.ExecuteReader();
                    int mnv ;
                    int quyen;
                    if (dulieu.Read() == true)
                    {
                    mnv = dulieu.GetInt32(3);
                    quyen = dulieu.GetInt32(2);
                    fMain f = new fMain(mnv,quyen);
                        this.Hide();
                        f.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Sai tên đăng nhập hoặc mật khẩu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                con.closeConnect();
            }
            catch (Exception loi)
            {
                MessageBox.Show("Lỗi kết nối!" + loi, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void fLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
