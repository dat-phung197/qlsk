﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlisangkienMBF
{
    public partial class qlcv : Form
    {
        int quyen;
        public qlcv(int i)
        {
            InitializeComponent();
            quyen = i;
            if (quyen != 1)
            {
                btn_sua.Enabled = false;
                btn_them.Enabled = false;
                btn_xoa.Enabled = false;
            }
        }
        ConnectDB con = new ConnectDB();
        private void qlcv_Load(object sender, EventArgs e)
        {
            Loadcv();
        }
        public void Loadcv()
        {
            CRUD crud = new CRUD();
            string sqlQuery = "select * from Chucvu";
            dataGridView1.DataSource = crud.getDataTable(sqlQuery);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                txt_ma.Text = row.Cells[0].Value.ToString();
                txt_Ten.Text = row.Cells[1].Value.ToString();
                txt_mota.Text = row.Cells[2].Value.ToString();
            }
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            con.openConnect();
            string sqlQuery = "INSERT INTO chucvu VALUES (@machucvu,@tenchucvu,@motachucvu)";
            SqlCommand cmd1 = new SqlCommand(sqlQuery, con.con);
            cmd1.Parameters.AddWithValue("machucvu", txt_ma.Text);
            cmd1.Parameters.AddWithValue("tenchucvu", txt_Ten.Text);
            cmd1.Parameters.AddWithValue("motachucvu", txt_mota.Text);
            cmd1.ExecuteNonQuery();
            con.closeConnect();
            MessageBox.Show("Tạo chức vụ thành công", "Thông báo");
            Loadcv();
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            try
            {
                con.closeConnect();
                con.openConnect();
                string sqlEdit = "UPDATE chucvu SET tenchucvu = @tenchucvu,motachucvu = @motachucvu WHERE machucvu = @machucvu";
                SqlCommand cmd1 = new SqlCommand(sqlEdit, con.con);
                cmd1.Parameters.AddWithValue("machucvu", txt_ma.Text);
                cmd1.Parameters.AddWithValue("tenchucvu", txt_Ten.Text);
                cmd1.Parameters.AddWithValue("motachucvu", txt_mota.Text);
                cmd1.ExecuteNonQuery();
                con.closeConnect();
                Loadcv();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chức vụ đã tồn tại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            try
            {

                con.closeConnect();
                con.openConnect();
                string sqlDelete = "DELETE FROM chucvu WHERE machucvu = @machucvu";
                SqlCommand cmd1 = new SqlCommand(sqlDelete, con.con);
                cmd1.Parameters.AddWithValue("machucvu", txt_ma.Text);
                cmd1.Parameters.AddWithValue("tenchucvu", txt_Ten.Text);
                cmd1.Parameters.AddWithValue("motachucvu", txt_mota.Text);
                cmd1.ExecuteNonQuery();
                con.closeConnect();
                Loadcv();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xóa thất bại ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
