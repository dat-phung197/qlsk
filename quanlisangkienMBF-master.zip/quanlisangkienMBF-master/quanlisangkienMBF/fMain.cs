﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlisangkienMBF
{
    public partial class fMain : Form
    {
        int mnv,quyen;
        ConnectDB con = new ConnectDB();
        private void fMain_Load(object sender, EventArgs e)
        {
            CRUD crud = new CRUD();
            string sqlQuery = " select * from view_thanhvienhoidong where mahoidong = (select max(hoidongkhoahoc.mahoidong) from hoidongkhoahoc);";
            //string sqlQuery = "select * from nhanvien where manhanvien = '" + mnv + "' ";
            dgv_tvhd.DataSource = crud.getDataTable(sqlQuery);
            con.openConnect();
            SqlDataReader dulieu;
            string sql = " select * from dotsangkien where madotsangkien = (select max(madotsangkien) from dotsangkien)";
            SqlCommand cmd = new SqlCommand(sql, con.con);
            dulieu = cmd.ExecuteReader();
            DateTime ngaybatdau, ngayketthuc, handangky, hannop;
            if (dulieu.Read() == true)
            {
                ngaybatdau = dulieu.GetDateTime(3);
                ngayketthuc = dulieu.GetDateTime(4);
                handangky = dulieu.GetDateTime(5);
                hannop = dulieu.GetDateTime(6);
                lb_ngaybatdau.Text = ngaybatdau.ToString("MM/dd/yyyy");
                lb_ngayketthuc.Text = ngayketthuc.ToString("MM/dd/yyyy");
                lb_handangky.Text = handangky.ToString("MM/dd/yyyy");
                lb_hannopbaocao.Text = hannop.ToString("MM/dd/yyyy");
            }
            con.closeConnect();

        }

        public fMain(int mnv,int quyen)
        {
            InitializeComponent();
            this.mnv = mnv;
            this.quyen = quyen;
            con.openConnect();
            if (quyen != 1)
            {
                admin_menu.Visible = false;
                duyet_menu.Visible = false;
            }
            else
            {
                admin_menu.Visible = true;
                duyet_menu.Visible = true;
            }
            if(quyen == 2)
            {
                chamdiem_menu.Visible = true;
            }
            else
            {
                chamdiem_menu.Visible = false;
            }
            if(quyen == 4)
            {
                menu_dk.Visible = true;
                menu_myidea.Visible = true;
            }
            else
            {
                menu_dk.Visible = false;
                menu_myidea.Visible = false;
            }
            txt_ten.Text = mnv.ToString();
            SqlDataReader dulieu;
            string sql = " select * from view_nhanvien where manhanvien = '" + mnv + "' ";
            SqlCommand cmd = new SqlCommand(sql, con.con);
            dulieu = cmd.ExecuteReader();
            string ten = "";
            string chucvu = "";
            string phongban = "";
            if (dulieu.Read() == true)
            {
                phongban = dulieu.GetString(3);
                chucvu = dulieu.GetString(2);
                ten = dulieu.GetString(1);
                txt_ten.Text = ten.ToString();
                lb_chucvu.Text = chucvu.ToString();
                lb_phongban.Text = phongban.ToString();
            }
            con.closeConnect();
        }

        private void fgToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            DialogResult h = MessageBox.Show
                ("Bạn có chắc muốn thoát không?", "Error", MessageBoxButtons.OKCancel);
            if (h == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void fgToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            fLogin f = new fLogin();
            this.Hide();
            f.ShowDialog();
        }

        private void thêmTàiKhoảnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addAccount f = new addAccount();
            this.Hide();
            f.ShowDialog();
        }
            private void cậpNhậpSángKiếnMớiToolStripMenuItem_Click(object sender, EventArgs e)
            {
                addsangkien f = new addsangkien();
                f.ShowDialog();
            }

        private void quảnLíNhânViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fNhanvien f = new fNhanvien(quyen);
            f.Show();
        }

        private void quảnLíTrạngTháiSángKiếnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            qlcv f = new qlcv(quyen);
            f.ShowDialog();
        }

        private void quảnLíXếpLoạiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Fhdgiamkhao f = new Fhdgiamkhao();
            f.ShowDialog();
        }

        private void ghToolStripMenuItem_Click(object sender, EventArgs e)
        {
            qlpb f = new qlpb(quyen);
            f.ShowDialog();
        }

        private void quảnLíĐợtSángKiếnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dsdsk f = new dsdsk(quyen);
            f.Show();
        }

        private void duyet_menu_Click(object sender, EventArgs e)
        {
            addsangkien f = new addsangkien();
            f.Show();
        }

        private void chamdiem_menu_Click(object sender, EventArgs e)
        {

            ChamDiem f = new ChamDiem(mnv);
            f.Show();
        }

        private void menu_myidea_Click(object sender, EventArgs e)
        {
            con.openConnect();
            SqlDataReader dulieu2;
            int sk = 0;
            string sqlcount = "select masangkien from view_nguoithamgia where manhanvien = '" + mnv + "'";
            SqlCommand cmd3 = new SqlCommand(sqlcount, con.con);
            dulieu2 = cmd3.ExecuteReader();
            if (dulieu2.Read() == true)
            {
                sk = dulieu2.GetInt32(0);
                con.closeConnect();
                Myidea f = new Myidea(mnv);
                f.Show();
            }
            else
            {
                MessageBox.Show("Bạn chưa đăng kí sáng kiến trong đợt này","Thông báo",MessageBoxButtons.OK);
            }

        }
        private void quảnLiSángKiếnToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void quảnLíChứcVụToolStripMenuItem_Click(object sender, EventArgs e)
        {
            qlcv f = new qlcv(quyen);
            f.ShowDialog();
        }

        private void cậpNhậpPhòngBanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            qlpb f = new qlpb(quyen);
            f.Show();
        }

        private void quảnLíĐợtSángKiếnToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            dsdsk f = new dsdsk(quyen);
            f.Show();
        }

        private void đăngKýSángKiếnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DKSK f = new DKSK();
            f.Show();
            
        }


    }
    }

