﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlisangkienMBF
{
    public partial class ChamDiem : Form
    {
        ConnectDB con = new ConnectDB();
        int mtv;
        public ChamDiem(int mnv)
        {
            InitializeComponent();
            con.openConnect();
            SqlDataReader dulieu2;
            int nv = mnv;
            string sqlcount = "select mathanhvien from thanhvienhoidong where manhanvien = '" + nv + "'";
            SqlCommand cmd3 = new SqlCommand(sqlcount, con.con);
            dulieu2 = cmd3.ExecuteReader();
            if (dulieu2.Read() == true)
            {
                mtv = dulieu2.GetInt32(0);
                con.closeConnect();
            }
            con.openConnect();
            SqlDataReader dulieu1;
            int mcv = 0;
            string sql1 = "select machucvuhd from view_tvhdht where manhanvien = '" + mnv + "'";
            SqlCommand cmd2 = new SqlCommand(sql1, con.con);
            dulieu1 = cmd2.ExecuteReader();
            if (dulieu1.Read() == true)
            {
                mcv = dulieu1.GetInt32(0);
                con.closeConnect();
            }
            if(mcv != 13)
            {
                btn_ht.Visible = false;
            }
        }

        public void Loaddatask()
        {
            CRUD crud = new CRUD();
            string sql = "select * from SangKien where (matrangthai = 2 or matrangthai = 5) and madotsangkien = (select max(madotsangkien) from sangkien)";
            dataGridView1.DataSource = crud.getDataTable(sql);
            string sql1 = "select * from SangKien where matrangthai = 3 and madotsangkien = (select max(madotsangkien) from sangkien) ";
            dataGridView2.DataSource = crud.getDataTable(sql1);
        }
        private void ChamDiem_Load(object sender, EventArgs e)
        {
            Loaddatask();
        }
        private void btn_ht_Click(object sender, EventArgs e)
        {
            string md, nd, ud, tb,msk;
            md = num_md.Value.ToString();
            nd = num_nd.Value.ToString();
            ud = num_ud.Value.ToString();
            tb = num_tb.Value.ToString();
            msk = txt_msk.Text;
            if (md.Trim() == "")
            {
                MessageBox.Show("Vui lòng chấm điểm nội dung");
                num_md.Focus();
            }
            else if (nd.Trim() == "")
            {
                MessageBox.Show("Vui lòng chấm điểm nội dung");
                num_nd.Focus();
            }
            else if (txt_msk.Text.Trim() == "")
            {
                MessageBox.Show("Chưa chọn sáng kiến để chấm điểm");
                txt_msk.Focus();
            }
            else if (ud.Trim() == "")
            {
                MessageBox.Show("Vui lòng chấm điểm ứng dụng");
                num_ud.Focus();
            }
            else if (tb.Trim() == "")
            {
                MessageBox.Show("Vui lòng chấm điểm trình bày");
                num_tb.Focus();
            }
            else if (txt_nx.Text.Trim() == "")
            {
                MessageBox.Show("Bạn chưa nhận xét sáng kiến");
                txt_nx.Focus();
            }
            else
            {
                try
                {
                    con.openConnect();
                    string sqlQuery = "INSERT INTO chitietchamdiem VALUES (@mathanhvien,@masangkien,@diem_muc_dich,@diem_noi_dung,@diem_ung_dung,@diem_trinh_bay)";
                    SqlCommand cmd = new SqlCommand(sqlQuery, con.con);
                    cmd.Parameters.AddWithValue("mathanhvien", mtv);
                    cmd.Parameters.AddWithValue("masangkien", txt_msk.Text);
                    cmd.Parameters.AddWithValue("diem_muc_dich", md);
                    cmd.Parameters.AddWithValue("diem_noi_dung", nd);
                    cmd.Parameters.AddWithValue("@diem_ung_dung", ud);
                    cmd.Parameters.AddWithValue("@diem_trinh_bay", tb);
                    cmd.ExecuteNonQuery();
                    con.closeConnect();
                    Loaddatask();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi không xác định", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                try
                {
                    int mnx = 0;
                    con.openConnect();
                    SqlDataReader dulieu;
                    string sql = "SELECT max(manhanxet) FROM nhanxet";
                    SqlCommand cmdread = new SqlCommand(sql, con.con);
                    dulieu = cmdread.ExecuteReader();
                    if (dulieu.Read() == true)
                    {
                        mnx = dulieu.GetInt32(0);
                        mnx = mnx + 1;
                    }
                    con.closeConnect();
                    string ma = Convert.ToString(mnx);
                    string ndnx = txt_nx.Text;
                    DateTime now = DateTime.Now;
                    String.Format("{0:MM/dd/yyyy}", now);
                    con.openConnect();
                    string sqlQuery = "INSERT INTO nhanxet VALUES (@manhanxet,@mathanhvien,@masangkien,@noidung,@thoigiannhanxet)";
                    SqlCommand cmd = new SqlCommand(sqlQuery, con.con);
                    cmd.Parameters.AddWithValue("manhanxet", ma.ToString());
                    cmd.Parameters.AddWithValue("mathanhvien", mtv.ToString());
                    cmd.Parameters.AddWithValue("masangkien", txt_msk.Text);
                    cmd.Parameters.AddWithValue("noidung", ndnx);
                    cmd.Parameters.AddWithValue("thoigiannhanxet", now);
                    cmd.ExecuteNonQuery();
                    con.closeConnect();
                    Loaddatask();
                    MessageBox.Show("Chấm điểm thành công ","Thong bao",MessageBoxButtons.OK);

                }
                catch
                {
                    MessageBox.Show("Xảy ra lỗi không xác định", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            con.openConnect();
            SqlDataReader dulieu1;
            int diem = 0;
            string sqlcount = "select count(masangkien) from chitietchamdiem where masangkien = '" + msk + "'";
            SqlCommand cmd2 = new SqlCommand(sqlcount, con.con);
            dulieu1 = cmd2.ExecuteReader();
            if (dulieu1.Read() == true)
            {
                diem = dulieu1.GetInt32(0);
                con.closeConnect();
            }
            if(diem >= 3)
            {
                string tt = "3";
                con.openConnect();
                string sqlQuery = "UPDATE sangkien SET matrangthai = @matrangthai WHERE masangkien = @masangkien";
                SqlCommand cmd = new SqlCommand(sqlQuery, con.con);
                cmd.Parameters.AddWithValue("masangkien", msk);
                cmd.Parameters.AddWithValue("matrangthai", tt);
                cmd.ExecuteNonQuery();
                con.closeConnect();
                Loaddatask();
            }
            else if(diem < 3 && diem >=1)
            {
                string tt = "5";
                con.openConnect();
                string sqlQuery = "UPDATE sangkien SET matrangthai = @matrangthai WHERE masangkien = @masangkien";
                SqlCommand cmd = new SqlCommand(sqlQuery, con.con);
                cmd.Parameters.AddWithValue("masangkien", msk);
                cmd.Parameters.AddWithValue("matrangthai", tt);
                cmd.ExecuteNonQuery();
                con.closeConnect();
                Loaddatask();
            }
            
            txt_nx.ResetText();
            txt_msk.ResetText();
            num_md.ResetText();
            num_nd.ResetText();
            num_tb.ResetText();
            num_ud.ResetText();
        }

        private void btn_re_Click(object sender, EventArgs e)
        {
            Loaddatask();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.openConnect();
            string sqlQuery = "select * from sangkien where masangkien = @masangkien";
            SqlCommand cmd = new SqlCommand(sqlQuery, con.con);
            cmd.Parameters.AddWithValue("masangkien", txt_msk.Text);
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            con.closeConnect();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                txt_msk.Text = row.Cells[0].Value.ToString();
            }
        }

        private void btn_chitiet_Click(object sender, EventArgs e)
        {
            int msk = int.Parse(txt_msk.Text);
            Myidea f = new Myidea(msk);
            f.Show();
        }
    }
}
